function validate(){
      var name_value=$("#name").val();
    var name_feedback="";
     
    if(name_value.length< 8){
        name_feedback="Username must be at least 8 characters long";
        $("#name")[0].setCustomValidity(name_feedback);
        $("#name-feedback").text(name_feedback);
    }
    else{
        $("#name")[0].setCustomValidity("");
    }


   var email_value=$("#email").val();
    var email_feedback="";
var n = email_value.includes("@");
 if( n == false){
        email_feedback="Please Enter a valid email ,include @";
        $("#email")[0].setCustomValidity(email_feedback);
        $("#email-feedback").text(email_feedback);
    }  
    else{
        $("#email")[0].setCustomValidity("");
    }
    var email_value=$("#email").val();
    var email_feedback="";
var n = email_value.includes(".com");
 if( n == false){
        email_feedback="Please Enter a valid email ,include also .com";
        $("#email")[0].setCustomValidity(email_feedback);
        $("#email-feedback").text(email_feedback);
    }
    else{
        $("#email")[0].setCustomValidity("");
    }
     var message_value=$("#message").val();
    var message_feedback="";
     
    if(message_value.length< 20){
        message_feedback="please enter a message with at least 20 characters";
        $("#message")[0].setCustomValidity(message_feedback);
        $("#message-feedback").text(message_feedback);
    }
    else{
        $("#message")[0].setCustomValidity("");
    }
    
    $("form").addClass("was-validated");
}
