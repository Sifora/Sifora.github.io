$(document).ready(init);




function init() {
    var mymap = L.map('map').setView([25.2048, 55.2708], 13);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        maxZoom: 20,
        minZoom: 10,
        attribution: 'Leaflet',
        id: 'mapbox/satellite-v9', 
        tileSize: 512,
        zoomOffset: -1
    }).addTo(mymap);
    
    var Dubai_mall = L.marker([25.1988, 55.2796]).addTo(mymap);
    Dubai_mall.bindPopup("<b>Dubai Mall</b>.");
    

    
    
}