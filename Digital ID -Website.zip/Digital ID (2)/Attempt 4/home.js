function calc_price() {
    var years=$("#years").val();
    var quality=$("#quality").val();
    var price=0;
    if(quality=="premium"){
        price=40*years;
    }
    else if(quality=="standard"){
        price=30*years;
    }
    
    else {
        price=20*years;
    }
    $("#result").html(price);  
    
      
}
