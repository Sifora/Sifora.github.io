function search_countries(){
    
    var search_text=$("#search-text").val();
     var table_html="";
    for (var index in countries){
        
          var country = countries[index];
        var Name=country[ "Name"];
        var IDname=country["IDname"];
        var issued=country["issued"];
        var name_index=Number(index)+1;
        
         
    if(Name.toLowerCase().search(search_text.toLowerCase())!=-1){
        table_html+= "<tr><th scope='row'>"+name_index+"</th><td>"+Name+"</td><td><span>"+ IDname+"</span></td> <td><span>"+issued+"</span</td></tr>";
    }
    }
    
    $("#movie_table").html(table_html);
}




function show_countries (){
    
    var table_html="";
    for (var index in countries){
        
       var country = countries[index];
        var Name=country[ "Name"];
        var IDname=country["IDname"];
        var issued=country["issued"];
        var name_index=Number(index)+1;
        table_html+= "<tr><th scope='row'>"+name_index+"</th><td>"+Name+"</td><td  ><span>"+ IDname+"</span></td> <td><span>"+issued+"</span</td></tr>";
    }
    
    $("#movie_table").html(table_html);
}